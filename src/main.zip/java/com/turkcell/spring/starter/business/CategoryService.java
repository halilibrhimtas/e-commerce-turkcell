package com.turkcell.spring.starter.business;
import com.turkcell.spring.starter.entities.Category;

import java.util.List;

public interface CategoryService {
    void add(Category var1);

    void delete(int id);

    void update(int id, Category category);
    List<Category> getAll();
    Category getById(int id);
}

