package com.turkcell.spring.starter.business;
import com.turkcell.spring.starter.entities.Product;

import java.util.List;

public interface ProductService {
    void add(Product var1);

    void delete(int id);

    void update(int id, Product product);
    List<Product> getAll();
    Product getById(int id);
}
