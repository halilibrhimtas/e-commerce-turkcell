package com.turkcell.spring.starter.business;

import com.turkcell.spring.starter.entities.Category;
import com.turkcell.spring.starter.repository.CategoryDal;

import java.util.List;

public class CategoryServiceImpl implements CategoryService {    CategoryDal categorydal;

    public CategoryServiceImpl(CategoryDal categoryDal) {
        this.categorydal = categoryDal;
    }

    @Override
    public void add(Category category) {
        categorydal.add(category);
    }

    @Override
    public void delete(int id) {
        categorydal.delete(id);
    }

    @Override
    public void update(int id, Category category) {
        categorydal.update(id, category);
    }

    @Override
    public List<Category> getAll() {
        return categorydal.getAll();
    }

    @Override
    public Category getById(int id) {
        return categorydal.getById(id);
    }
}
