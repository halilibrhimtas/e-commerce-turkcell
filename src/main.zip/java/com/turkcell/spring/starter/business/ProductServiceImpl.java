package com.turkcell.spring.starter.business;

import com.turkcell.spring.starter.entities.Product;
import com.turkcell.spring.starter.repository.ProductDal;

import java.util.List;

public class ProductServiceImpl implements ProductService {
    ProductDal productDal;

    public ProductServiceImpl(ProductDal productDal) {
        this.productDal = productDal;
    }

    @Override
    public void add(Product product) {
        productDal.add(product);
    }

    @Override
    public void delete(int id) {
        productDal.delete(id);
    }

    @Override
    public void update(int id, Product product) {
        this.productDal.update(id, product);
    }


    @Override
    public List<Product> getAll() {
      return this.productDal.getAll();
    }

    @Override
    public Product getById(int id) {
        return this.productDal.getById(id);
    }
}
