package com.turkcell.spring.starter.controllers;

import com.turkcell.spring.starter.entities.Product;
import com.turkcell.spring.starter.repository.InMemoryProductDal;
import org.springframework.web.bind.annotation.*;
import com.turkcell.spring.starter.business.ProductService;
import com.turkcell.spring.starter.business.ProductServiceImpl;

import java.util.List;

@RestController
@RequestMapping("products")
public class ProductController {
    ProductService productService = new ProductServiceImpl(new InMemoryProductDal());
    @GetMapping("get")
    public List<Product> get(){
        return productService.getAll();
    }

    //http://localhost:8083/products/getById?id=2
    @GetMapping("getById")
    public Product getById(@RequestParam("id") int id){
        return productService.getById(id);
    }

    @PostMapping("add")
    public void add(@RequestBody Product product){
        productService.add(product);
    }

    //http://localhost:8083/products/delete?id=1
    @PostMapping("delete")
    public void delete(@RequestParam("id") int id){
        productService.delete(id);
    }

    //http://localhost:8083/products/update?id=3
    @PostMapping("update")
    public void update(@RequestParam("id") int id, @RequestBody Product product){
        productService.update(id, product);
    }
}
