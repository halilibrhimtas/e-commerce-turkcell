package com.turkcell.spring.starter.controllers;

import com.turkcell.spring.starter.business.CategoryService;
import com.turkcell.spring.starter.business.CategoryServiceImpl;
import com.turkcell.spring.starter.entities.Category;
import com.turkcell.spring.starter.repository.InMemoryCategoryDal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("categories")
public class CategoryController {
    CategoryService categoryService = new CategoryServiceImpl(new InMemoryCategoryDal());

    @GetMapping("get")
    public List<Category> get(){
        return categoryService.getAll();
    }

    @GetMapping("getById")
    public Category getById(@RequestParam("id") int id){
        return categoryService.getById(id);
    }

    @PostMapping("add")
    public void add(@RequestBody Category category){
        categoryService.add(category);
    }

    @PostMapping("delete")
    public void delete(@RequestParam("id") int id){
        categoryService.delete(id);
    }

    @PostMapping("update")
    public void update(@RequestParam("id") int id, @RequestBody Category category){
        categoryService.update(id, category);
    }
}
