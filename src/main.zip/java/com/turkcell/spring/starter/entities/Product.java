package com.turkcell.spring.starter.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product {
    public String name;
    public double price;
    public int stock;
    public int id;
}
