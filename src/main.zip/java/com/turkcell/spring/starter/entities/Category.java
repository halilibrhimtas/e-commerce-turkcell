package com.turkcell.spring.starter.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Category {
    public String name;
    public String description;
    public int id;
}
