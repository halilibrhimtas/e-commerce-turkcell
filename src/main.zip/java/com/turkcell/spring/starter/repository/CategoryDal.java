package com.turkcell.spring.starter.repository;

import java.util.List;
import com.turkcell.spring.starter.entities.Category;
import org.springframework.http.ResponseEntity;

public interface CategoryDal {
    void add(Category category);

    List<Category> getAll();

    ResponseEntity<?> update(int id, Category category);

    ResponseEntity<?> delete(int var1);

    Category getById(int id);
}

