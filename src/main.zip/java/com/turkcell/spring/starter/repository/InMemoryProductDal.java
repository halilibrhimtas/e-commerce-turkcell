package com.turkcell.spring.starter.repository;

import com.turkcell.spring.starter.entities.Product;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

public class InMemoryProductDal implements ProductDal{

    List<Product> products = new ArrayList();


    @Override
    public void add(Product product) {
        products.add(product);
    }

    @Override
    public List<Product> getAll() {
        return this.products;
    }

    @Override
    public ResponseEntity<?> update(int id, Product product) {
        for (int i = 0; i < products.size(); i++){
            if(product.getId() == id){
                products.set(i,product);
                return ResponseEntity.ok("Ürün başarıyla güncellendi");
            }
        }
        return ResponseEntity.notFound().build();
    }

    @Override
    public ResponseEntity<?> delete(int id) {
        for (Product product : products){
            if(product.getId() == id){
                products.remove(product);
                return ResponseEntity.ok("Ürün başarıyla silindi");
            }
        }
        return ResponseEntity.notFound().build();
    }

    @Override
    public Product getById(int id) {
        for (Product product : products){
            if(product.getId() == id){
                return product;
            }
        }
        return null;
    }
}
