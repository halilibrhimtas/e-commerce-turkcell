package com.turkcell.spring.starter.repository;

import com.turkcell.spring.starter.entities.Category;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

public class InMemoryCategoryDal implements CategoryDal{

    List<Category> categoryList = new ArrayList();

    @Override
    public void add(Category category) {
        categoryList.add(category);
    }

    @Override
    public List<Category> getAll() {
        return this.categoryList;
    }

    @Override
    public ResponseEntity<?> update(int id, Category category) {
        for (int i = 0; i < categoryList.size(); i++){
            if(category.getId() == id){
                categoryList.set(i,category);
                return ResponseEntity.ok("Kategori başarıyla güncellendi");
            }
        }
        return ResponseEntity.notFound().build();
    }

    @Override
    public ResponseEntity<?> delete(int id) {
        for (Category category : categoryList){
            if(category.getId() == id){
                categoryList.remove(category);
                return ResponseEntity.ok("Categori başarıyla silindi");
            }
        }
        return ResponseEntity.notFound().build();
    }

    @Override
    public Category getById(int id) {
        for (Category category : categoryList){
            if(category.getId() == id){
                return category;
            }
        }
        return null;
    }
}
