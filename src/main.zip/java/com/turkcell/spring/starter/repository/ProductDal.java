package com.turkcell.spring.starter.repository;

import java.util.List;
import com.turkcell.spring.starter.entities.Product;
import org.springframework.http.ResponseEntity;

public interface ProductDal {
    void add(Product var1);

    List<Product> getAll();

    ResponseEntity<?> update(int id, Product product);

    ResponseEntity<?> delete(int var1);

    Product getById(int id);
}

