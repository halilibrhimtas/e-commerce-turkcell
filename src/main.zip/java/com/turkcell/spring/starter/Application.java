package com.turkcell.spring.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.turkcell.spring.starter.entities.Product;
import com.turkcell.spring.starter.repository.ProductDal;
import com.turkcell.spring.starter.repository.InMemoryProductDal;
import com.turkcell.spring.starter.business.ProductService;
import com.turkcell.spring.starter.business.ProductServiceImpl;
@SpringBootApplication
public class Application {

	public static void main(String[] args) { SpringApplication.run(Application.class, args);}

}


